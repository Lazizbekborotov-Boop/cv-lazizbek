import telebot
from telebot import types
from pydub import AudioSegment
import os
import speech_recognition as sr

# 🔑 Bot tokeningizni shu yerga yozing
TOKEN = "8240772785:AAEAUA-uwd1LUPV_uWREkEXd3P3Qbzdh2fU"
bot = telebot.TeleBot(TOKEN)

# 🔊 /start buyrug‘i
@bot.message_handler(commands=['start'])
def start(msg):
    bot.reply_to(msg, "Salom! Men ovozli suhbat botiman 🎙")

# 🎤 Ovozli xabarni qabul qilish
@bot.message_handler(content_types=['voice'])
def handle_voice(message):
    try:
        # Telegramdan ovozli faylni olish
        file_info = bot.get_file(message.voice.file_id)
        downloaded_file = bot.download_file(file_info.file_path)

        with open("input.ogg", "wb") as f:
            f.write(downloaded_file)

        # OGG → WAV
        audio = AudioSegment.from_ogg("input.ogg")
        audio.export("input.wav", format="wav")

        # Ovozdan matnni aniqlash
        r = sr.Recognizer()
        with sr.AudioFile("input.wav") as source:
            audio_data = r.record(source)
            try:
                text = r.recognize_google(audio_data, language="uz-UZ")
            except sr.UnknownValueError:
                text = "Kechirasiz, ovozni tushunolmadim."
            except sr.RequestError:
                text = "Xatolik yuz berdi. Internet aloqasini tekshiring."

        # Javob matnini yaratish
        reply_text = f"Siz aytdingiz: {text}"

        # Mac ovoz sintezi (chiqishni yashirish)
        os.system(f'say -v Milena "{reply_text}" -o response.aiff >/dev/null 2>&1')

        # AIFF → OGG
        audio = AudioSegment.from_file("response.aiff")
        audio.export("response.ogg", format="ogg")

        # Javobni yuborish
        with open("response.ogg", "rb") as voice:
            bot.send_voice(message.chat.id, voice)

    except Exception as e:
        bot.send_message(message.chat.id, f"Xatolik yuz berdi: {e}")

    finally:
        # Oraliq fayllarni tozalash
        for file in ["input.ogg", "input.wav", "response.aiff", "response.ogg"]:
            if os.path.exists(file):
                os.remove(file)

# 💬 Matnli xabar uchun javob
@bot.message_handler(content_types=['text'])
def handle_text(message):
    reply_text = f"Siz yozdingiz: {message.text}"
    os.system(f'say -v Milena "{reply_text}" -o response.aiff >/dev/null 2>&1')
    audio = AudioSegment.from_file("response.aiff")
    audio.export("response.ogg", format="ogg")
    with open("response.ogg", "rb") as voice:
        bot.send_voice(message.chat.id, voice)
    os.remove("response.aiff")
    os.remove("response.ogg")

# 🔁 Botni ishga tushirish
print("🤖 Bot ishga tushdi...")
bot.infinity_polling(timeout=60, long_polling_timeout=60)
